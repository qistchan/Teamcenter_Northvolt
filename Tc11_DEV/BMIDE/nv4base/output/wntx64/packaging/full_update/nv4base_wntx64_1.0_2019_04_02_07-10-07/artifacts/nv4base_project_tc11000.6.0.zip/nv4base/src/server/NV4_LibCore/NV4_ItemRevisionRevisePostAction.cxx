//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension NV4_ItemRevisionRevisePostAction
 *
 */
#include <NV4_LibCore/NV4_ItemRevisionRevisePostAction.hxx>
#include <NV4_LibCore/NV4_CoreHeader.h>
#pragma warning (disable:C4189)//(METHOD_id_t messageMethod = msg->method;)
int NV4_ItemRevisionRevisePostAction( METHOD_message_t * msg, va_list args )
{
 
	TC_write_syslog("\n Entering D4_PartRevisionRevisePostAction  \n");
	int iFail = ITK_ok;
	tag_t tSrcItemRev = va_arg(args, tag_t);
	//const char* rev_id = va_arg(args, char*);
	tag_t *tNewRevision = va_arg(args, tag_t*);// New  Revision tag
	char*cObjRevID = NULL;char*cObjNewRevID = NULL;
	METHOD_id_t messageMethod = msg->method;
	messageMethod.id;
	tag_t tLatestRev = tNewRevision[0];
	AOM_ask_value_string(tSrcItemRev,REV_ID, &cObjRevID);
	TC_write_syslog("\n cObjRevID--> %s \n", cObjRevID);
	AOM_ask_value_string(tLatestRev,REV_ID, &cObjNewRevID);
	TC_write_syslog("\n cObjNewRevID--> %s \n", cObjNewRevID);

	int     n_references 			= 0, *levels = NULL;
	tag_t * reference_tags 			= NULL;
	char ** relations 			= NULL;
	TC_write_syslog("\n ready to implement..........\n");

	//if(tNewItem!=NULLTAG && (tc_strcmp(cObjRevID , "A") != 0))
	//{
		ITK(WSOM_where_referenced(tSrcItemRev,1,&n_references, &levels, &reference_tags,&relations));
		 TC_write_syslog("\n referenced  count : %d \n",n_references);
		 if(n_references > 0)
								{
									for (int ii = 0; ii < n_references; ii++)
									{
										char  *		type		=    NULL;
										ITK(WSOM_ask_object_type2(reference_tags[ii], &type));
										TC_write_syslog("\n type : %s \n",type);
										if(tc_strcmp("Folder", type)==0)
										{
											TC_write_syslog("\n Yes I am folder");
											iFail =  AOM_refresh(reference_tags[ii], true);
											if(tLatestRev!=NULLTAG)
											{
												iFail =  FL_insert(reference_tags[ii], tLatestRev, 999);
												iFail =  AOM_save(reference_tags[ii]);
												iFail =  AOM_refresh(reference_tags[ii], false);
												iFail =  AOM_unload(reference_tags[ii]);
											}
											//if (tItems) MEM_free(tItems);

										}
									}
								}




	return iFail;

}
