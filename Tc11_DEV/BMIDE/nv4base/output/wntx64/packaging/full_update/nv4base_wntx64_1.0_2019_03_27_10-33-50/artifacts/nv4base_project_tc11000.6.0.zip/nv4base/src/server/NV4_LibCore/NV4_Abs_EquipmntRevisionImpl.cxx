//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object NV4_Abs_EquipmntRevisionImpl
//

#include <NV4_LibCore/NV4_Abs_EquipmntRevisionImpl.hxx>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <list>
#include <algorithm>
#include <stdlib.h>

#include <tccore/aom_prop.h>
#include <tccore/project.h>
#include <tc/preferences.h>

#include <user_exits/epm_toolkit_utils.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/uom.h>
#include <property/nr.h>

using namespace nv4base;

//----------------------------------------------------------------------------------
// NV4_Abs_EquipmntRevisionImpl::NV4_Abs_EquipmntRevisionImpl(NV4_Abs_EquipmntRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
NV4_Abs_EquipmntRevisionImpl::NV4_Abs_EquipmntRevisionImpl( NV4_Abs_EquipmntRevision& busObj )
   : NV4_Abs_EquipmntRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// NV4_Abs_EquipmntRevisionImpl::~NV4_Abs_EquipmntRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
NV4_Abs_EquipmntRevisionImpl::~NV4_Abs_EquipmntRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// NV4_Abs_EquipmntRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int NV4_Abs_EquipmntRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = NV4_Abs_EquipmntRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// finalize operation input
/// @param pSavAsInput - desc
/// @param vecDeepCopyData - desc
/// @return - returns an int
///
int  NV4_Abs_EquipmntRevisionImpl::finalizeSaveAsInputBase( ::Teamcenter::SaveAsInput *pSavAsInput, std::vector<  ::Teamcenter::DeepCopyData* > *vecDeepCopyData )
{
	int ifail = ITK_ok;
	    TC_write_syslog("\n\t Entering D4_Abs_EquipmentRevisionImpl::finalizeSaveAsInputBase \n");

	    // Call the parent Implementation
	    ifail = NV4_Abs_EquipmntRevisionImpl::super_finalizeSaveAsInputBase( pSavAsInput, vecDeepCopyData);
	    TC_write_syslog("\n\t I am here.......1111111111111111111111111......\n");
	    // Your Implementation
	    std::string gObjName;        //Get the Object Name value
	    		bool isNull = false ;
	    		char*cObjectType = NULL;
	    		char*cObjectType1 = NULL;
	    		  tag_t tNewObj = NULLTAG;
	    		//  tag_t   tItem               = NULLTAG;
	    		//std::string ErrorMsg="";
	    		//Get the input data for the new object created as a part of SaveAs
	    	//	pSavAsInput->getString("d4_sample_item",gObjName,isNull);
	    	//	pSavAsInput->setString("d4_compound_sampleitem","N",false);
	    	//	pSavAsInput->getString("d4_compound_sampleitem",gObjName,isNull);
	    		//TC_write_syslog("\n\t value of sample is %s \n", gObjName.c_str());
	    		  TC_write_syslog("\n\t I am here.......2222222222222222222222222......\n");
	    		pSavAsInput->getTag("newTargetObject",tNewObj,isNull);
	    		TC_write_syslog("\tNewTarObj Tag : %d\n",tNewObj);
	    		if(tNewObj!=NULLTAG)
	    		{
	    			logical isLoaded = false;
	    			ifail,POM_is_loaded(tNewObj,&isLoaded);

	    			if(isLoaded)
	    					 {
	    						 TC_write_syslog("\n Source Object :loaded");
	    						// AOM_set_value_string(tNewObj,"d4_sample_item", "No");
	    						 AOM_set_value_string(tNewObj,"nv4_is_supplieritem", "N");
	    						 AOM_ask_value_string(tNewObj,"object_type", &cObjectType);
	    						 AOM_ask_value_string(tNewObj,"nv4_is_supplieritem", &cObjectType1);
	    						 TC_write_syslog("\n object type is %s\n", cObjectType);
	    						// ITEM_ask_item_of_rev(tNewObj,&tItem);
	    						// AOM_ask_value_string(tItem,"object_type", &cObjectType1);
	    						TC_write_syslog("\n ocObjectType1,,,object type is %s\n", cObjectType1);
	    					 }
	    					 else
	    					 {
	    						 TC_write_syslog("\n Source Object :not loaded");
	    						 ifail =AOM_load(tNewObj);
	    						 TC_write_syslog("\nAOM_load : %d ",ifail);
	    						 ifail =AOM_refresh(tNewObj,FALSE);
	    						 TC_write_syslog("\nAOM_refresh: %d ",ifail);



	    					 }
	    		}
	    		//pSavAsInput->getString("d4_compound_sampleitem",gObjName,isNull);
	    		//TC_write_syslog("\n\t value of sample is %s \n", gObjName.c_str());
	    	    // Your Implementation
	    		 /*
	    		 if(tc_strcmp(gObjName.c_str(),"Yes")==0)
	    			{
	    				ifail= ErrorCodeForSupplier;
	    				ErrorMsg = "Change the sample item to No and proceed for SaveAs...";
	    				EMH_store_error_s1( EMH_severity_error, ifail, ErrorMsg.c_str());
	    				return ifail;
	    			}
	*/
	    		 TC_write_syslog("\n\t I am here.......3333333333333333333333......\n");
	    return ifail;
}
